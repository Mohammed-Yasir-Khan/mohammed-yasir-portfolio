---
name: Obsidian SRE Editorial
colors:
  surface: '#141312'
  surface-dim: '#141312'
  surface-bright: '#3b3937'
  surface-container-lowest: '#0f0e0d'
  surface-container-low: '#1d1b1a'
  surface-container: '#211f1e'
  surface-container-high: '#2b2a28'
  surface-container-highest: '#363433'
  on-surface: '#e6e1df'
  on-surface-variant: '#e2bfb3'
  inverse-surface: '#e6e1df'
  inverse-on-surface: '#32302f'
  outline: '#a98a7f'
  outline-variant: '#594139'
  surface-tint: '#ffb59a'
  primary: '#ffb59a'
  on-primary: '#5b1b00'
  primary-container: '#ff6b2c'
  on-primary-container: '#5c1c00'
  inverse-primary: '#a83900'
  secondary: '#68dc9d'
  on-secondary: '#003920'
  secondary-container: '#28a46a'
  on-secondary-container: '#00311b'
  tertiary: '#cfc5ba'
  on-tertiary: '#353028'
  tertiary-container: '#a1988e'
  on-tertiary-container: '#363129'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdbcf'
  primary-fixed-dim: '#ffb59a'
  on-primary-fixed: '#380d00'
  on-primary-fixed-variant: '#802900'
  secondary-fixed: '#85f9b7'
  secondary-fixed-dim: '#68dc9d'
  on-secondary-fixed: '#002111'
  on-secondary-fixed-variant: '#005230'
  tertiary-fixed: '#ebe1d5'
  tertiary-fixed-dim: '#cfc5ba'
  on-tertiary-fixed: '#1f1b14'
  on-tertiary-fixed-variant: '#4c463d'
  background: '#141312'
  on-background: '#e6e1df'
  surface-variant: '#363433'
typography:
  display-hero:
    fontFamily: Playfair Display
    fontSize: 5.5rem
    fontWeight: '400'
    lineHeight: 5.75rem
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Playfair Display
    fontSize: 3rem
    fontWeight: '400'
    lineHeight: 3.25rem
    letterSpacing: -0.02em
  headline-xl:
    fontFamily: Playfair Display
    fontSize: 3.5rem
    fontWeight: '400'
    lineHeight: 3.75rem
    letterSpacing: -0.025em
  headline-xl-mobile:
    fontFamily: Playfair Display
    fontSize: 2.25rem
    fontWeight: '400'
    lineHeight: 2.5rem
    letterSpacing: -0.015em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 2.5rem
    fontWeight: '400'
    lineHeight: 2.875rem
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 1.75rem
    fontWeight: '400'
    lineHeight: 2.125rem
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Geist
    fontSize: 1.5rem
    fontWeight: '500'
    lineHeight: 2rem
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Geist
    fontSize: 1.125rem
    fontWeight: '500'
    lineHeight: 1.625rem
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Geist
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 1.875rem
    letterSpacing: '0'
  body-md:
    fontFamily: Geist
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.625rem
    letterSpacing: '0'
  body-sm:
    fontFamily: Geist
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.375rem
    letterSpacing: '0'
  label-code:
    fontFamily: JetBrains Mono
    fontSize: 0.8125rem
    fontWeight: '400'
    lineHeight: 1.25rem
    letterSpacing: 0.02em
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 0.6875rem
    fontWeight: '500'
    lineHeight: 1rem
    letterSpacing: 0.12em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 3rem
---

## Brand & Style

This design system establishes an editorial technical identity for Mohammed Yasir Khan (DevOps / SRE / AI Engineer). The visual language bridges two historically disparate disciplines: the typographic rigor and intentional pacing of an elite printed broadsheet, and the uncompromising precision of low-level infrastructure telemetry.

Key brand tenets:
- **Quiet Authority:** We eschew noisy glow effects, saturated purple gradients, and gimmicky terminal emulators. Instead, we project competence through vast negative space, structural alignment, and pristine typographic scale.
- **Architectural Mechanics:** Structural boundaries are explicit, rendered with strict 1-pixel hairline dividers reminiscent of both blueprint drafts and terminal buffer splits.
- **Audience & Resonance:** Targeted toward CTOs, Staff-plus systems engineers, and frontier AI infrastructure leaders. The UI evokes reliability, high cognitive bandwidth, and meticulous craftsmanship.

## Colors

The system uses an ink-and-warm-stone hierarchy optimized primarily for an organic dark mode, complemented by a newsprint-inspired light mode. 

### Palette Tokens

- **Dark Mode (Default Canvas):**
  - Background (Canvas): `#0F0E0D` — deep, uncompressed carbon with warm brown undertones.
  - Surface (Elevations & Cards): `#171513` — low-reflectance structural slate.
  - Border (Hairlines): `#2A2622` — subtle structural separation; high legibility without visual distraction.
  - Text Primary: `#F2EEE8` — off-white archival vellum.
  - Text Muted: `#8D857B` — neutral warm stone for secondary details and indexes.
  - Accent (Ember): `#FF6B2C` — tactical highlight representing hot operational states, alerts, or active interactions.
  - System Status: `#3FB67A` — telemetry green denoting availability, live services, and nominal states.

- **Light Mode (Archival Canvas):**
  - Background: `#F6F3EE` — warm bone/newsprint.
  - Surface: `#FFFFFF` — crisp foreground separation.
  - Border: `#E1DBD2` — muted linen boundary lines.
  - Text Primary: `#1A1714` — dense carbon ink.
  - Text Muted: `#6F675D` — weathered lithographic charcoal.
  - Accent: `#D9480F` — deep rust ochre for sustained contrast on light fields.
  - System Status: `#2B8A5B` — balanced emerald indicator.

Contrast ratios for text must meet or exceed WCAG AAA standards (7:1) across primary copy, with metadata labels maintaining WCAG AA (4.5:1).

## Typography

Typography drives the compositional weight of this design system through a disciplined three-family hierarchy:

1. **Playfair Display (Display & Headlines):** Infuses literary craftsmanship and editorial poise. Used for massive, commanding headings, statement pull quotes, and project titles. Always set with tight negative tracking to maintain solid, carved wordforms.
2. **Geist (Body & Structural Layout):** Provides hyper-neutral, precision-engineered geometric grotesque legibility. Used for essays, project overviews, client contexts, and primary interaction elements.
3. **JetBrains Mono (Telemetry, Metadata & System Labels):** Anchors the technical reality of DevOps, clusters, and operational engineering. Rendered strictly in uppercase for section markers (e.g., `01 / SELECTED WORK`, `UPTIME: 99.99%`), telemetry chips, commit hashes, and system logs.

## Layout & Spacing

The layout is grounded in an uncompromising **12-column architectural grid** framed by structured hairlines.

- **Desktop (1024px+):** 12 equal-width columns with 24px (`1.5rem`) gutters and a minimum 48px (`3rem`) page margin. Content can break across asymmetrical boundaries (e.g., metadata column spans 4, editorial copy spans 8).
- **Tablet (768px – 1023px):** 6-column grid with 20px gutters and 32px margins.
- **Mobile (< 768px):** 4-column reflow with 16px (`1rem`) gutters and 20px (`1.25rem`) lateral margins. Stacked layouts convert horizontal editorial bands into vertically separated hairline rows.

Spacing follows an arithmetic scale optimized for generous vertical whitespace, giving heavy display serif typography room to breathe while clamping monospace metadata in dense, disciplined clusters.

## Elevation & Depth

This system intentionally eliminates blur effects, colored drop-shadows, glow matrices, and frosted translucent backdrops. Depth is articulated exclusively through **planar value stratification and 1px crisp hairline borders**:

- **Ground Level (Canvas):** Pure `#0F0E0D` tone.
- **Structured Surface (Tier 1):** `#171513` filled containers bounded by explicit `1px solid #2A2622` outlines. 
- **Interactive Planes (Tier 2 / Hover):** Subtle background shift from `#171513` to `#1D1A17` accompanied by hairline contrast shifting to `#3E3933`. No elevation or Z-axis shift occurs on hover; all states remain strictly architectural.
- **Focus / Command Overlay (Cmd+K):** A direct planar overlay backed by a `#0F0E0D` surface with 95% opacity (no blur), framed by a precise 1px ember `#FF6B2C` accent boundary.

## Shapes

The form language is disciplined, engineered, and near-orthogonal:
- Standard UI containers, cards, interactive inputs, and buttons are restricted to **4px to 6px corner radii** (`roundedness: 1`).
- Section borders and grid boundaries must remain absolute rectangles (`0px` border-radius) to uphold the hairline broadsheet rhythm.
- The sole exception to the low-radius rule is the operational telemetry pill (e.g., the "Available for work" status badge), which uses a full pill curve (`9999px`) to visually signal a dynamic hardware-style LED pill.

## Components

### 1. Sticky Navigation Bar
- **Dimensions & Placement:** Fixed top, full viewport width, height 64px, anchored over `#0F0E0D` with a subtle bottom hairline border (`1px solid #2A2622`).
- **Wordmark:** Monospace or clean grotesque `'MYK'` set at `0.875rem`, tracked wide (`0.1em`), weighted medium.
- **Telemetry Pill:** Status container featuring an illuminated status dot (`#3FB67A`, 6px × 6px) with a soft pulsing border (custom CSS ring without heavy blur), accompanied by `AVAILABLE FOR WORK` in `label-caps`.
- **Theme & Command Hint:** Quick access theme toggle alongside a keyboard command hint `Cmd+K` encased in a 1px border container (`fontFamily: JetBrains Mono`, font-size `0.6875rem`, padding `2px 6px`, radius `3px`).

### 2. Buttons & Triggers
- **Primary Action:** Solid ember `#FF6B2C` background, `#0F0E0D` high-contrast typography (`fontFamily: Geist`, weight `500`, radius `4px`, padding `10px 20px`). Hover shifts background to `#FF7F47`.
- **Secondary / Console Trigger:** Transparent surface with `1px solid #2A2622` border, primary text color, and `JetBrains Mono` label. On hover, hairline border steps to `#8D857B`.

### 3. Project Index Rows (Editorial List Format)
- Instead of typical generic web cards, key projects are displayed as full-width index rows separated by `1px solid #2A2622` hairlines.
- **Columns:** 
  - Monospace index (`01`, `02`, `03`) in column 1–2.
  - Display project headline (`headline-lg`) in column 3–8.
  - Stack tags (`Kubernetes`, `eBPF`, `Terraform`, `vLLM`) in column 9–10.
  - Year/Status label in column 11–12.
- **Hover State:** Row background transitions linearly to `#171513`, text accent jumps to `#FF6B2C`, and a directional arrow indicator (`→`) smoothly translates 4px right.

### 4. Ops Console Cards
- **Structure:** Modular containers featuring an explicit top telemetry bar with monospaced metadata (e.g., `CLUSTER: PROD-US-EAST`, `LATENCY: 12ms`, `HEALTH: 100%`).
- **Dividers:** Internal hairline splits between card header, metric body, and system summary.
- **Border:** `1px solid #2A2622`, radius `6px`.

### 5. Quiet Hairline Footer
- **Layout:** 12-column grid bound by a continuous top hairline border.
- **Content:** Left-aligned copyright and UTC runtime timestamp in `JetBrains Mono`; right-aligned editorial outbound links (`GITHUB`, `LINKEDIN`, `GPG KEY`, `STATUS`) rendered in `label-caps` with subtle border underlines.